from django.contrib import admin
from .models import Tagam
from .models import Makal
from .models import Pikir


# Register your models here.
admin.site.register(Tagam)
admin.site.register(Makal)
admin.site.register(Pikir)
